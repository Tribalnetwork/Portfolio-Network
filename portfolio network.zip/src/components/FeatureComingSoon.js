import React from 'react';
import './FeatureComingSoon.css'

export const FeatureComingSoon = () => {
  return (
    <div className="featureComingSoon">
      <p className="featureComingSoon__text">This Feature Is Coming Soon</p>
    </div>
  )
}
