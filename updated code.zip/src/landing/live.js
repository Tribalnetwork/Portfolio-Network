import React from 'react';
import './live.css'


const Live = () => {
    
    return(
        <div className='LiveDiv'>
            <h1>I'm Going Live</h1>
        </div>
    )
}

export default Live