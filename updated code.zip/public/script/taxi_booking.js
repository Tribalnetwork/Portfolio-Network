$('.open_close_nav').click(function(){

    $('.responsive_nav_bar').toggleClass('responsive_bar');
    });
    
  