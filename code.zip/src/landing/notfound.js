import React from 'react';
import './notfound.css'


const Notfound = (props) => {
    return (
    
            <div className='NotfoundDiv'>
            <h1>Whaaaaat?</h1>
            <h2>It's not here</h2>
            </div>
          
    )
  }
  
  export default Notfound