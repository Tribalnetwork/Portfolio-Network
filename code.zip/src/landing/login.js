import React from 'react';
import './login.css'
import './responsive-styles.css'


const Login = () => {
    
    return(
        <div className='LoginDiv'>
            <h1>Log in to T3</h1>
        </div>
    )
}

export default Login